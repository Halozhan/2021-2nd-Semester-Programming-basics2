#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def hello1(name):
    x = "%s 님 안녕하세요" % name
    return x

def hello2(name):
    x = "%s 님 반갑습니다." % name
    return x

def hello3(name):
    x = "%s 님 만나서 반갑습니다." % name
    return x